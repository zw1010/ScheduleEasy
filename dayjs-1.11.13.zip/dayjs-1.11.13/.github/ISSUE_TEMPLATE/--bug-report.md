---
name: "\U0001F4A9Bug report"
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**Expected behavior**
A clear and concise description of what you expected to happen.

**Information**
 - Day.js Version [e.g. v1.0.0]
 - OS: [e.g. iOS]
 - Browser [e.g. chrome 62]
 - Time zone: [e.g. GMT-07:00 DST (Pacific Daylight Time)]
